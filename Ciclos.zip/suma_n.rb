n = ARGV[0].to_i

constante = 0 

n.times do |i|
    constante = i * 51
end
puts constante





