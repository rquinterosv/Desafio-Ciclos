a = 0
50.times do |i|
    a += 1
end
puts a 